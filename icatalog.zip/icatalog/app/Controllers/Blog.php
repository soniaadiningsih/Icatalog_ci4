<?php 

declare(strict_types=1);

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use CodeIgniter\Controller;

class Blog extends Controller 
{
    use ResponseTrait;

    public function index()
    {
        $db = \Config\Database::connect();

        $query = $db->query("SELECT * FROM tb_akun");
        $results = $query->getResultArray();

        return $this->respond($results);
    }
}