<?php
// application/Controllers/Api/Ping.php
declare(strict_types=1);
 
namespace App\Controllers\Api;
 
use function time;
 
use CodeIgniter\API\ResponseTrait;
use CodeIgniter\Controller;
use CodeIgniter\HTTP\ResponseInterface;
 
class Ping extends Controller
{

    use ResponseTrait;
 
    public function index(): ResponseInterface
    {
        return $this->respond(['ack' => time()]);
    }
}

?>