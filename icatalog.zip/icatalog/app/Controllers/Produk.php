<?php 

declare(strict_types=1);

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use CodeIgniter\Controller;

class Produk extends Controller 
{
    use ResponseTrait;

    public function index()
    {
        $db = \Config\Database::connect();
        $query = $db->query('SELECT * FROM tb_produk');
        $result = $query->getResultArray();

        return $this->respond($result);
    }

    public function view($id = null) 
    {
        $db = \Config\Database::connect();
        $query = $db->query('SELECT * FROM tb_produk WHERE id = '.$id);
        $result = $query->getResultArray();

        return $this->respond($result);
    }

    public function store()
    {
        try {
            helper('text');
     
            $db = \Config\Database::connect();
    
            $nama = $this->request->getVar('nama');
            $deskripsi = $this->request->getVar('deskripsi');
            $id_kate = $this->request->getVar('id_kate');
            $link = $this->request->getVar('link');
            $gambarName1 = $this->request->getVar('gambar1');
            $gambarName2 = $this->request->getVar('gambar2');
            $gambarName3 = $this->request->getVar('gambar3');
            $id_akun = $this->request->getVar('id_akun');
    
            $sql = 'INSERT INTO tb_produk ( nama, deskripsi, id_kate, link, gambar1, gambar2, gambar3, id_akun ) VALUES ('
                        .$db->escape($nama).','
                        .$db->escape($deskripsi).','
                        .$db->escape($id_kate).','
                        .$db->escape($link).','
                        .$db->escape($gambarName1).','
                        .$db->escape($gambarName2).','
                        .$db->escape($gambarName3).','
                        .$db->escape($id_akun).
                    ')';
    
            $db->query($sql);
    
            $api = [
                'success' => true,
                'message' => 'Data Berhasil ditambah',
            ];
    
            return $this->respond($api);
        } catch (\Exception $th) {
            $api = [
                'success' => false,
                'message' => 'Data gagal ditambah',
                'error' => $th
            ];
    
            return $this->respond($api);
        }
    }
}