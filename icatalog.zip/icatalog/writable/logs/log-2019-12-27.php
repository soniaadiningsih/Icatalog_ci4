<?php defined('SYSTEMPATH') || exit('No direct script access allowed'); ?>

CRITICAL - 2019-12-27 13:05:43 --> No connection could be made because the target machine actively refused it.

#0 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(377): CodeIgniter\Database\MySQLi\Connection->connect(false)
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(643): CodeIgniter\Database\BaseConnection->initialize()
#2 C:\xampp\htdocs\icatalog\system\Database\BaseBuilder.php(1783): CodeIgniter\Database\BaseConnection->query('SELECT *\nFROM `...', Array, false)
#3 C:\xampp\htdocs\icatalog\system\Model.php(474): CodeIgniter\Database\BaseBuilder->get()
#4 C:\xampp\htdocs\icatalog\app\Models\UserModel.php(24): CodeIgniter\Model->first()
#5 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(28): App\Models\UserModel->getUsers('1')
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->view('1')
#7 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#8 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#9 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#10 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#11 {main}
CRITICAL - 2019-12-27 13:08:07 --> No connection could be made because the target machine actively refused it.

#0 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(377): CodeIgniter\Database\MySQLi\Connection->connect(false)
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(643): CodeIgniter\Database\BaseConnection->initialize()
#2 C:\xampp\htdocs\icatalog\system\Database\BaseBuilder.php(1783): CodeIgniter\Database\BaseConnection->query('SELECT *\nFROM `...', Array, false)
#3 C:\xampp\htdocs\icatalog\system\Model.php(1675): CodeIgniter\Database\BaseBuilder->get()
#4 C:\xampp\htdocs\icatalog\app\Models\UserModel.php(24): CodeIgniter\Model->__call('get', Array)
#5 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(28): App\Models\UserModel->getUsers('1')
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->view('1')
#7 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#8 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#9 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#10 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#11 {main}
CRITICAL - 2019-12-27 13:13:38 --> No connection could be made because the target machine actively refused it.

#0 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(377): CodeIgniter\Database\MySQLi\Connection->connect(false)
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(643): CodeIgniter\Database\BaseConnection->initialize()
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(32): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->view('1')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 13:14:30 --> No connection could be made because the target machine actively refused it.

#0 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(377): CodeIgniter\Database\MySQLi\Connection->connect(false)
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(643): CodeIgniter\Database\BaseConnection->initialize()
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(32): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->view('1')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:00:58 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:01:09 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:01:56 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:02:05 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:02:13 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:02:14 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:02:46 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:02:47 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:02:48 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:03:35 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:03:46 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:04:48 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:04:52 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:05:29 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:05:49 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:05:50 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:06:10 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:06:22 --> Unknown column 'register' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(28): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->view('register')
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-27 18:06:28 --> Unknown column 'register' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(28): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->view('register')
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-27 18:08:33 --> Unknown column 'register' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(28): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->view('register')
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-27 18:08:46 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:08:53 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:08:55 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:08:59 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:09:00 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-27 18:10:57 --> Encrypter needs a starter key.
#0 C:\xampp\htdocs\icatalog\system\Encryption\Encryption.php(157): CodeIgniter\Encryption\Exceptions\EncryptionException::forNeedsStarterKey()
#1 C:\xampp\htdocs\icatalog\system\Config\Services.php(236): CodeIgniter\Encryption\Encryption->initialize(Object(Config\Encryption))
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(38): CodeIgniter\Config\Services::encrypter()
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
