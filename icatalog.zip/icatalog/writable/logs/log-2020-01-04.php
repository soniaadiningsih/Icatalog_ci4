<?php defined('SYSTEMPATH') || exit('No direct script access allowed'); ?>

CRITICAL - 2020-01-04 20:25:59 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Produk1Coba','Produk1Coba Deskripis','1','gooog.com','15781911581578191158_9463a' at line 1
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO tb_...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO tb_...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO tb_...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Produk.php(60): CodeIgniter\Database\BaseConnection->query('INSERT INTO tb_...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Produk->store()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Produk))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2020-01-04 20:27:09 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Produk1Coba','Produk1Coba Deskripis','1','gooog.com','15781912291578191229_7c110' at line 1
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO tb_...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO tb_...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO tb_...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Produk.php(62): CodeIgniter\Database\BaseConnection->query('INSERT INTO tb_...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Produk->store()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Produk))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2020-01-04 20:27:26 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Produk1Coba','Produk1Coba Deskripis','1','goog;e.com','15781912461578191246_e39b' at line 1
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO tb_...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO tb_...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO tb_...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Produk.php(62): CodeIgniter\Database\BaseConnection->query('INSERT INTO tb_...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Produk->store()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Produk))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2020-01-04 20:27:33 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Produk1Coba','Produk1Coba Deskripis','1','google.com','15781912531578191253_2d0b' at line 1
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO tb_...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO tb_...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO tb_...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Produk.php(62): CodeIgniter\Database\BaseConnection->query('INSERT INTO tb_...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Produk->store()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Produk))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2020-01-04 20:28:16 --> Unknown column 'gamba2' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO tb_...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO tb_...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO tb_...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Produk.php(62): CodeIgniter\Database\BaseConnection->query('INSERT INTO tb_...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Produk->store()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Produk))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2020-01-04 20:28:40 --> Unknown column 'gamba2' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO tb_...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO tb_...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO tb_...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Produk.php(62): CodeIgniter\Database\BaseConnection->query('INSERT INTO tb_...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Produk->store()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Produk))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2020-01-04 20:37:59 --> Unknown column 'gamba2' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO tb_...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO tb_...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO tb_...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Produk.php(61): CodeIgniter\Database\BaseConnection->query('INSERT INTO tb_...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Produk->store()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Produk))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2020-01-04 20:39:21 --> Unknown column 'gamba2' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO tb_...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO tb_...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO tb_...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Produk.php(61): CodeIgniter\Database\BaseConnection->query('INSERT INTO tb_...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Produk->store()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Produk))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2020-01-04 20:43:06 --> Unknown column 'gamba2' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO tb_...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO tb_...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO tb_...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Produk.php(65): CodeIgniter\Database\BaseConnection->query('INSERT INTO tb_...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Produk->store()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Produk))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2020-01-04 20:43:23 --> Unknown column 'gamba2' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO tb_...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO tb_...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO tb_...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Produk.php(59): CodeIgniter\Database\BaseConnection->query('INSERT INTO tb_...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Produk->store()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Produk))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2020-01-04 20:43:50 --> Unknown column 'gamba2' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO tb_...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO tb_...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO tb_...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Produk.php(58): CodeIgniter\Database\BaseConnection->query('INSERT INTO tb_...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Produk->store()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Produk))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
