<?php defined('SYSTEMPATH') || exit('No direct script access allowed'); ?>

CRITICAL - 2019-12-29 00:52:39 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'create' at line 1
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Kategori.php(31): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Kategori->show('create')
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Kategori))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-29 00:53:11 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'create' at line 1
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Kategori.php(31): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Kategori->show('create')
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Kategori))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-29 00:53:28 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'create' at line 1
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Kategori.php(31): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Kategori->show('create')
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Kategori))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-29 00:54:05 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'create' at line 1
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Kategori.php(31): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Kategori->show('create')
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Kategori))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-29 00:54:32 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'create' at line 1
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Kategori.php(31): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Kategori->show('create')
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Kategori))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-29 00:56:15 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'create' at line 1
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Kategori.php(31): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Kategori->show('create')
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Kategori))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-29 00:56:29 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'create' at line 1
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Kategori.php(31): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Kategori->show('create')
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Kategori))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-29 00:58:04 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'create' at line 1
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Kategori.php(31): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Kategori->show('create')
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Kategori))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-29 00:58:15 --> You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'create' at line 1
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Kategori.php(31): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Kategori->show('create')
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Kategori))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
