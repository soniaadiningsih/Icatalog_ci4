<?php defined('SYSTEMPATH') || exit('No direct script access allowed'); ?>

CRITICAL - 2019-12-28 12:44:09 --> No connection could be made because the target machine actively refused it.

#0 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(377): CodeIgniter\Database\MySQLi\Connection->connect(false)
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(643): CodeIgniter\Database\BaseConnection->initialize()
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(19): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->index()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-28 12:44:19 --> No connection could be made because the target machine actively refused it.

#0 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(377): CodeIgniter\Database\MySQLi\Connection->connect(false)
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(643): CodeIgniter\Database\BaseConnection->initialize()
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(19): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->index()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-28 12:44:48 --> No connection could be made because the target machine actively refused it.

#0 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(377): CodeIgniter\Database\MySQLi\Connection->connect(false)
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(643): CodeIgniter\Database\BaseConnection->initialize()
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(19): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->index()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-28 12:45:21 --> No connection could be made because the target machine actively refused it.

#0 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(377): CodeIgniter\Database\MySQLi\Connection->connect(false)
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(643): CodeIgniter\Database\BaseConnection->initialize()
#2 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(19): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->index()
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#6 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#7 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#8 {main}
CRITICAL - 2019-12-28 13:51:04 --> Unknown column 'register' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(27): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->view('register')
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 13:51:30 --> Unknown column 'register' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(27): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->view('register')
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 14:14:45 --> Unknown column 'email' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO `tb...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO `tb...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO `tb...')
#3 C:\xampp\htdocs\icatalog\system\Database\BaseBuilder.php(2166): CodeIgniter\Database\BaseConnection->query('INSERT INTO `tb...', Array, false)
#4 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(41): CodeIgniter\Database\BaseBuilder->insert(Array)
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#7 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#9 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#10 {main}
CRITICAL - 2019-12-28 14:16:09 --> Unknown column 'email' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO `tb...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO `tb...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO `tb...')
#3 C:\xampp\htdocs\icatalog\system\Database\BaseBuilder.php(2166): CodeIgniter\Database\BaseConnection->query('INSERT INTO `tb...', Array, false)
#4 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(41): CodeIgniter\Database\BaseBuilder->insert(Array)
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#7 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#9 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#10 {main}
CRITICAL - 2019-12-28 14:17:47 --> Unknown column 'email' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO `tb...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO `tb...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO `tb...')
#3 C:\xampp\htdocs\icatalog\system\Database\BaseBuilder.php(2166): CodeIgniter\Database\BaseConnection->query('INSERT INTO `tb...', Array, false)
#4 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(47): CodeIgniter\Database\BaseBuilder->insert(Array)
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#7 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#9 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#10 {main}
CRITICAL - 2019-12-28 14:17:53 --> Unknown column 'email' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO `tb...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO `tb...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO `tb...')
#3 C:\xampp\htdocs\icatalog\system\Database\BaseBuilder.php(2166): CodeIgniter\Database\BaseConnection->query('INSERT INTO `tb...', Array, false)
#4 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(47): CodeIgniter\Database\BaseBuilder->insert(Array)
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#7 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#9 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#10 {main}
CRITICAL - 2019-12-28 14:18:09 --> Unknown column 'email' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO `tb...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO `tb...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO `tb...')
#3 C:\xampp\htdocs\icatalog\system\Database\BaseBuilder.php(2166): CodeIgniter\Database\BaseConnection->query('INSERT INTO `tb...', Array, false)
#4 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(47): CodeIgniter\Database\BaseBuilder->insert(Array)
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#7 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#9 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#10 {main}
CRITICAL - 2019-12-28 14:18:24 --> Unknown column 'email' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO `tb...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO `tb...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO `tb...')
#3 C:\xampp\htdocs\icatalog\system\Database\BaseBuilder.php(2166): CodeIgniter\Database\BaseConnection->query('INSERT INTO `tb...', Array, false)
#4 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(47): CodeIgniter\Database\BaseBuilder->insert(Array)
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#7 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#9 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#10 {main}
CRITICAL - 2019-12-28 14:22:38 --> Unknown column 'email' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO `tb...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO `tb...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO `tb...')
#3 C:\xampp\htdocs\icatalog\system\Database\BaseBuilder.php(2166): CodeIgniter\Database\BaseConnection->query('INSERT INTO `tb...', Array, false)
#4 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(47): CodeIgniter\Database\BaseBuilder->insert(Array)
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#7 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#9 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#10 {main}
CRITICAL - 2019-12-28 14:22:41 --> Unknown column 'email' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO `tb...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO `tb...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO `tb...')
#3 C:\xampp\htdocs\icatalog\system\Database\BaseBuilder.php(2166): CodeIgniter\Database\BaseConnection->query('INSERT INTO `tb...', Array, false)
#4 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(47): CodeIgniter\Database\BaseBuilder->insert(Array)
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#7 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#9 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#10 {main}
CRITICAL - 2019-12-28 14:23:15 --> Unknown column 'email' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO `tb...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO `tb...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO `tb...')
#3 C:\xampp\htdocs\icatalog\system\Database\BaseBuilder.php(2166): CodeIgniter\Database\BaseConnection->query('INSERT INTO `tb...', Array, false)
#4 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(47): CodeIgniter\Database\BaseBuilder->insert(Array)
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#7 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#9 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#10 {main}
CRITICAL - 2019-12-28 14:23:43 --> Unknown column 'email' in 'field list'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('INSERT INTO `tb...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('INSERT INTO `tb...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('INSERT INTO `tb...')
#3 C:\xampp\htdocs\icatalog\system\Database\BaseBuilder.php(2166): CodeIgniter\Database\BaseConnection->query('INSERT INTO `tb...', Array, false)
#4 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(47): CodeIgniter\Database\BaseBuilder->insert(Array)
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#7 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#8 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#9 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#10 {main}
CRITICAL - 2019-12-28 14:27:00 --> syntax error, unexpected '}'
#0 C:\xampp\htdocs\icatalog\system\Autoloader\Autoloader.php(296): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\icatalog\system\Autoloader\Autoloader.php(258): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(801): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(328): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 14:27:11 --> syntax error, unexpected '}'
#0 C:\xampp\htdocs\icatalog\system\Autoloader\Autoloader.php(296): CodeIgniter\Autoloader\Autoloader->requireFile('C:\\xampp\\htdocs...')
#1 C:\xampp\htdocs\icatalog\system\Autoloader\Autoloader.php(258): CodeIgniter\Autoloader\Autoloader->loadInNamespace('App\\Controllers...')
#2 [internal function]: CodeIgniter\Autoloader\Autoloader->loadClass('App\\Controllers...')
#3 [internal function]: spl_autoload_call('App\\Controllers...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(801): class_exists('\\App\\Controller...', true)
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(328): CodeIgniter\CodeIgniter->startController()
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 14:38:36 --> hash() expects parameter 2 to be string, null given
#0 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(39): hash('sha256', NULL)
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#6 {main}
CRITICAL - 2019-12-28 14:39:06 --> Call to undefined function App\Controllers\random_string()
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 14:39:30 --> Call to undefined function App\Controllers\random_string()
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 14:46:35 --> Call to undefined function App\Controllers\random_string()
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 14:47:43 --> Call to undefined function App\Controllers\random_string()
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 14:48:42 --> Call to undefined function App\Controllers\random_string()
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 14:49:26 --> Call to undefined function App\Controllers\random_string()
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 14:49:34 --> Call to undefined function App\Controllers\random_string()
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 14:50:18 --> Call to undefined function App\Controllers\random_string()
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 14:52:23 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 14:52:47 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 14:53:00 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 14:53:32 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 14:54:00 --> Call to a member function str_random() on null
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 14:55:46 --> Call to a member function helper() on null
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->register()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 15:22:20 --> Unknown column 'Matiin' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(72): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 15:23:38 --> Unknown column 'Matiin' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(72): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 15:23:58 --> Unknown column 'Matiin' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(72): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 15:24:06 --> Unknown column 'Matiin' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(71): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 15:25:14 --> Unknown column 'Matiin' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(71): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 15:25:34 --> Unknown column 'ONinno' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(71): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 15:25:41 --> Unknown column 'ONinno' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(70): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 15:27:12 --> Unknown column 'Matiin' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(71): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 15:27:19 --> Unknown column 'Ninno' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(71): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 15:27:52 --> Unknown column 'Ninno' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(73): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 15:28:22 --> Unknown column 'Ninno' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT * FROM t...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT * FROM t...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT * FROM t...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(73): CodeIgniter\Database\BaseConnection->query('SELECT * FROM t...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 15:31:39 --> Unknown column 'Ninno' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT username...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT username...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT username...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(73): CodeIgniter\Database\BaseConnection->query('SELECT username...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 15:32:23 --> Unknown column 'Ninno' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT username...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT username...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT username...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(73): CodeIgniter\Database\BaseConnection->query('SELECT username...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 15:32:24 --> Unknown column 'Ninno' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT username...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT username...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT username...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(73): CodeIgniter\Database\BaseConnection->query('SELECT username...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 15:32:25 --> Unknown column 'Ninno' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT username...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT username...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT username...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(73): CodeIgniter\Database\BaseConnection->query('SELECT username...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 15:33:17 --> Unknown column 'ONinno' in 'where clause'
#0 C:\xampp\htdocs\icatalog\system\Database\MySQLi\Connection.php(330): mysqli->query('SELECT username...')
#1 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(738): CodeIgniter\Database\MySQLi\Connection->execute('SELECT username...')
#2 C:\xampp\htdocs\icatalog\system\Database\BaseConnection.php(666): CodeIgniter\Database\BaseConnection->simpleQuery('SELECT username...')
#3 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(73): CodeIgniter\Database\BaseConnection->query('SELECT username...')
#4 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#5 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#6 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2019-12-28 15:47:10 --> password_verify() expects parameter 2 to be string, array given
#0 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(87): password_verify('12345678', Array)
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#6 {main}
CRITICAL - 2019-12-28 15:48:06 --> password_verify() expects parameter 2 to be string, array given
#0 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(87): password_verify('12345678', Array)
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#6 {main}
CRITICAL - 2019-12-28 15:48:52 --> password_verify() expects parameter 2 to be string, array given
#0 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(87): password_verify('12345678', Array)
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#6 {main}
CRITICAL - 2019-12-28 15:49:21 --> password_verify() expects parameter 2 to be string, array given
#0 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(87): password_verify('12345678', Array)
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#6 {main}
CRITICAL - 2019-12-28 15:50:29 --> password_verify() expects parameter 2 to be string, array given
#0 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(87): password_verify('1234567890', Array)
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#6 {main}
CRITICAL - 2019-12-28 15:57:36 --> password_verify() expects parameter 2 to be string, object given
#0 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(80): password_verify('1234567890', Object(stdClass))
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#6 {main}
CRITICAL - 2019-12-28 15:57:52 --> Cannot use object of type stdClass as array
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 15:59:05 --> Cannot use object of type stdClass as array
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 16:02:12 --> Argument 2 passed to App\Controllers\Users::respond() must be of the type int or null, object given, called in C:\xampp\htdocs\icatalog\app\Controllers\Users.php on line 85
#0 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(85): App\Controllers\Users->respond('1234567890', Object(stdClass))
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#6 {main}
CRITICAL - 2019-12-28 16:04:14 --> Call to undefined method CodeIgniter\Database\MySQLi\Result::getQuery()
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 16:04:22 --> Call to undefined method CodeIgniter\Database\MySQLi\Result::getQuery()
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 16:04:32 --> Call to undefined method CodeIgniter\Database\MySQLi\Result::getOriginalQuery()
#0 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#3 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#4 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#5 {main}
CRITICAL - 2019-12-28 16:07:00 --> Illegal string offset 'password'
#0 C:\xampp\htdocs\icatalog\app\Controllers\Users.php(80): CodeIgniter\Debug\Exceptions->errorHandler(2, 'Illegal string ...', 'C:\\xampp\\htdocs...', 80, Array)
#1 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(847): App\Controllers\Users->login()
#2 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(338): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Users))
#3 C:\xampp\htdocs\icatalog\system\CodeIgniter.php(246): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#4 C:\xampp\htdocs\icatalog\public\index.php(45): CodeIgniter\CodeIgniter->run()
#5 C:\xampp\htdocs\icatalog\system\Commands\Server\rewrite.php(34): require_once('C:\\xampp\\htdocs...')
#6 {main}
